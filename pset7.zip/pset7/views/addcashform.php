<form action="addcash.php" method="POST">
    <div class="form-group" id="addcashform">
        <input type="text" name="cash" placeholder="Cash Amount"/><br>
    </div>
    <div class="form-group" id="addcashformbutton">
        <button class="btn btn-default" type="submit">
            Submit
        </button>
    </div>
</form>
