<form action="buy.php" method="POST">
    <div class="form-group" id="buyform">
        <input type="text" name="symbol" placeholder="symbol" maxlength="4"/><br>
        <input type="text" name="shares" placeholder="shares"/><br>
    </div>
    <div class="form-group" id="buyformbutton">
        <button class="btn btn-default" type="submit">
            Submit
        </button>
    </div>
</form>
