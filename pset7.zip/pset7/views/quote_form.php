<form action="quote.php" method="POST">
    <fieldset>
        <div class="form-group">
            <input name="symbol" placeholder="stock code" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                Submit
            </button>
        </div>
    </fieldset>
</form>

