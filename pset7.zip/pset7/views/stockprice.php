<p>
      The price for <?php echo $values["name"]; ?> is 
<?php
      $price=number_format($values["price"],2);
      echo $price;
?>  
</p>
